Layer Stack:
Top - switchBoard.top
Bottom - switchBoard.bot

Drill File:
drill_1_16.xln

Other:
Top Silkscreen - switchBoard.tsk
Bottom Silkscreen - switchBoard.bsk
Top Solder Mask - switchBoard.tsm
Bottom Solder Mask - switchBoard.bsm
Board Outline/Dimensions - switchBoard.dim
