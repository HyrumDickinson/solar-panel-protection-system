Layer Stack:
Top - smartInterface.top
Layer 2 - smartInterface.ly2
Layer 3 - smartInterface.ly3
BOTTOM - smartInterface.bot

Drill File:
drill_1_16.xln

Other:
Top Silkscreen - smartInterface.tsk
Bottom Silkscreen - smartInterface.bsk
Top Solder Mask - smartInterface.tsm
Bottom Solder Mask - smartInterface.bsm
Board Outline/Dimensions - smartInterface.dim
